package com.example.projecttest

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edtQuarto = findViewById<EditText>(R.id.edt_quarto)
        val chkCafe = findViewById<CheckBox>(R.id.chk_cafe)
        val chkLeite = findViewById<CheckBox>(R.id.chk_leite)
        val chkSuco = findViewById<CheckBox>(R.id.chk_suco)
        val rgFrutas = findViewById<RadioGroup>(R.id.rg_frutas)
        val switchLactose = findViewById<Switch>(R.id.switch_lactose)
        val spinnerGluten = findViewById<Spinner>(R.id.spinner_gluten)
        val btnSalvar = findViewById<Button>(R.id.btn_salvar)

        chkSuco.setOnCheckedChangeListener { _, isChecked ->
            rgFrutas.isEnabled = isChecked
            for (i in 0 until rgFrutas.childCount) {
                rgFrutas.getChildAt(i).isEnabled = isChecked
            }
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, listOf("Sim", "Não"))
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerGluten.adapter = adapter

     btnSalvar.setOnClickListener {
            val quarto = edtQuarto.text.toString()
            val cafeManha = listOfNotNull(
                if (chkCafe.isChecked) "Café" else null,
                if (chkLeite.isChecked) "Leite" else null,
                if (chkSuco.isChecked) "Suco" else null
            ).joinToString(", ")

            val frutaSelecionada = findViewById<RadioButton>(rgFrutas.checkedRadioButtonId)?.text ?: "Nenhuma"

            val lactose = if (switchLactose.isChecked) "Sim" else "Não"
            val gluten = spinnerGluten.selectedItem.toString()

            val mensagem = """
                Quarto: $quarto
                Café da manhã: $cafeManha
                Fruta: $frutaSelecionada
                Intolerância à Lactose: $lactose
                Alergia ao Glúten: $gluten
            """.trimIndent()

            AlertDialog.Builder(this)
                .setTitle("Confirmação")
                .setMessage(mensagem)
                .setIcon(android.R.drawable.ic_dialog_info)
                .setPositiveButton("Sim") { _, _ -> Toast.makeText(this, "Salvo!", Toast.LENGTH_SHORT).show() }
                .setNegativeButton("Não", null)
                .show()
        }
    }
}
