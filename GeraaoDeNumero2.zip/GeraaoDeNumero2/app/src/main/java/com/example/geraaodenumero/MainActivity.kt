package com.example.geraaodenumero

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnGerar = findViewById<Button>(R.id.btnGerar)
        val txtResultado = findViewById<TextView>(R.id.txtResultado)

        btnGerar.setOnClickListener {
            val numeroAleatorio = Random.nextInt(0, 101)
            txtResultado.text = "Número gerado: $numeroAleatorio"
        }
    }
}
